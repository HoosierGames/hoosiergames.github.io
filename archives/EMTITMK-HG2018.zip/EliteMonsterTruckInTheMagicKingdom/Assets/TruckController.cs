﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TruckController : MonoBehaviour {

    // Use this for initialization
    void Start () {
	jumping = false;
	falling = false;

	this.transform.position = new Vector2(this.transform.position.x,
					      floor);

	this.mouth.SetActive(false);
    }

    bool jumping, falling;
    public float floor = 0.0f;
    private float jumpTime = 0.0f;
    public float maxJumpTime = 0.5f;

    private float accel;
    public float maxAccel = 8.0f;
    public float minAccel = 4.0f;

    public int health = 2;

    public GameObject mouth;

    enum dir {
	left,
	right,
    }

    private dir currentDir;

    private float mouthOpen = 0.0f;
    public float maxMouthOpen = 1.0f;
    public float defaultMouthOpenCooldown = 0.01f;
    private float mouthOpenCooldown = 0.0f;

    public Sprite closed;
    public Sprite open;

    void OnTriggerEnter2D(Collider2D other) {
	if(mouthOpen > 0.0f && mouthOpenCooldown <= 0.0f) {
	    Destroy(other.gameObject);
	}
	else {
	    --health;

	    if(health == 0) {
		// you lose
	    }
	}
    }
	
    // Update is called once per frame
    void Update () {
	print(this.mouthOpenCooldown);

	if(Input.GetKeyDown("space") && Mathf.Approximately(mouthOpen, 0.0f) && mouthOpenCooldown <= 0.0f) {
	    // Attack now.	    
	    this.mouth.SetActive(true);
	    GetComponent<SpriteRenderer>().sprite = open;
	}

	if(this.mouth.active) {
	    this.mouthOpen += Time.deltaTime;
	}

	if(mouthOpen >= maxMouthOpen) {
	    this.mouth.SetActive(false);
	    this.mouthOpenCooldown = this.defaultMouthOpenCooldown;
	    this.mouthOpen = 0.0f;
	    GetComponent<SpriteRenderer>().sprite = closed;
	}

	if(this.mouthOpenCooldown > 0.0f) {
	    this.mouthOpenCooldown -= Time.deltaTime;
	}

	if(Input.GetKey("d")) {
	    if(this.currentDir == dir.right) {
		this.accel = Mathf.Min(this.accel + (Time.deltaTime * 3.0f), this.maxAccel);
	    }
	    else {
		this.accel = this.minAccel;
		this.currentDir = dir.right;
	    }
	    
	    this.transform.position = new Vector2(this.transform.position.x + (this.accel * Time.deltaTime),
						  this.transform.position.y);
	}

	if(Input.GetKey("a")) {
	    if(this.currentDir == dir.left) {
		this.accel = Mathf.Min(this.accel + (Time.deltaTime * 3.0f), this.maxAccel);
	    }
	    else {
		this.accel = this.minAccel;
		this.currentDir = dir.left;
	    }
	
	    this.transform.position = new Vector2(this.transform.position.x - (this.accel * Time.deltaTime),
						  this.transform.position.y);
	}

	if(Input.GetKey("w") && !jumping && !falling) {
	    this.jumping = true;
	    this.jumpTime = 0.0f;
	}
		
	if(jumping && (Input.GetKeyUp("w") ||
		       this.jumpTime >= this.maxJumpTime)) {
	    this.jumping = false;
	    this.falling = true;
	}

	if(this.jumping) {
	    this.transform.position = new Vector2(this.transform.position.x,
						  this.transform.position.y + (8.0f * Time.deltaTime));
	    this.jumpTime += Time.deltaTime;
	}

	if(this.falling) {
	    this.transform.position = new Vector2(this.transform.position.x,
						  this.transform.position.y - (8.0f * Time.deltaTime));

	    print("fall testing");
	    if(this.transform.position.y < floor) {
		this.transform.position = new Vector2(this.transform.position.x,
						      floor);
		this.falling = false;
		print("STOP");
	    }
	}

	Camera.main.transform.position = new Vector3(this.transform.position.x, Camera.main.transform.position.y, Camera.main.transform.position.z);
    }
}
